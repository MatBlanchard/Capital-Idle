# Capital Idle Android (solo hors ligne)

Cette application embarque Capital Idle Mobile v0.5 dans une WebView Android. Aucun serveur ni connexion Internet nécessaire pour jouer. Les données de jeu sont enregistrées dans le stockage de l'application via localStorage. Le bouton « Exporter JSON » utilise le sélecteur de fichiers Android pour enregistrer la sauvegarde ; « Importer » permet de la restaurer.

## Compiler uniquement avec un téléphone

1. Sur github.com, créez un dépôt **privé** nommé `CapitalIdleAndroid`.
2. Téléversez **le contenu** de ce dossier (et non le dossier parent) dans le dépôt. Attention : le dossier caché `.github/workflows/` doit être conservé. Depuis un téléphone, le plus simple est d'utiliser l'application GitHub ou un gestionnaire de fichiers capable d'extraire le ZIP puis de téléverser les fichiers ; GitHub Web ne prend pas toujours en charge l'import de dossiers entiers. Une alternative est d'utiliser un environnement de développement cloud tel que github.dev pour transférer les fichiers.
3. Ouvrez **Actions** → **Construire APK Android** → **Run workflow**. Le premier push sur `main` lance aussi la compilation automatiquement.
4. Quand le workflow est terminé, ouvrez son exécution → **Artifacts** → `CapitalIdle-APK` et téléchargez le ZIP. Décompressez-le sur le téléphone.
5. Ouvrez `app-debug.apk`, autorisez si nécessaire l'installation depuis cette source et installez.

## Sauvegardes et mises à jour

Avant chaque mise à jour, utilisez **Sauver → Exporter JSON**. La sauvegarde locale reste normalement disponible si une mise à jour est installée **par-dessus** l'application avec le même identifiant et la même clé de signature. **Attention :** les APK debug générés sur des exécutions GitHub Actions distinctes peuvent être signés avec des clés différentes. Ils peuvent donc refuser de s'installer par-dessus la version précédente. Dans ce cas, exportez votre sauvegarde avant de désinstaller l'ancienne application, puis importez-la dans la nouvelle.

Pour des mises à jour transparentes, configurer à terme une **clé de signature release stable** dans les secrets GitHub Actions (ne jamais la committer).

## Limites

- Solo uniquement : pas de serveur multijoueur.
- Pas de migration automatique des données stockées par Chrome vers l'APK : utilisez l'export JSON de la version navigateur puis l'import dans l'application.
- Le projet est prêt pour compilation cloud mais n'a pas été compilé/testé sur un appareil Android dans cet environnement.
- L'interface est celle du jeu v0.5 ; elle n'est pas une interface Android native.
